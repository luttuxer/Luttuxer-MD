<p align="center">
  <h1 align="center">𝙇𝙪𝙩𝙩𝙪𝙭𝙚𝙧 𝙈𝘿</h1>
</p>

<p align="center">
  <b>🤖 𝙋𝙚𝙧𝙨𝙤𝙣𝙖𝙡 𝙒𝙝𝙖𝙩𝙨𝘼𝙥𝙥 𝘽𝙤𝙩</b>
</p>

<p align="center">
  <img src="./mention.gif" width="500">
</p>

---

## ✨ 𝙁𝙚𝙖𝙩𝙪𝙧𝙚𝙨

🏓 𝙋𝙞𝙣𝙜 & 𝙇𝙖𝙩𝙚𝙣𝙘𝙮  
❤️ 𝘾𝙪𝙨𝙩𝙤𝙢 𝘼𝙡𝙞𝙫𝙚 𝙈𝙚𝙨𝙨𝙖𝙜𝙚  
👑 𝙊𝙬𝙣𝙚𝙧 𝘾𝙤𝙢𝙢𝙖𝙣𝙙  
📜 𝙎𝙩𝙮𝙡𝙞𝙨𝙝 𝙈𝙚𝙣𝙪  
⏱️ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚  
🏷️ 𝙏𝙖𝙜 𝘼𝙡𝙡  
🖼️ 𝙎𝙩𝙞𝙘𝙠𝙚𝙧 𝘾𝙧𝙚𝙖𝙩𝙞𝙤𝙣  
👁️ 𝙑𝙞𝙚𝙬-𝙊𝙣𝙘𝙚 𝙈𝙚𝙙𝙞𝙖  
🎙️ 𝙈𝙚𝙣𝙩𝙞𝙤𝙣 𝙑𝙤𝙞𝙘𝙚 𝙍𝙚𝙥𝙡𝙮  
👀 𝘼𝙪𝙩𝙤 𝙎𝙩𝙖𝙩𝙪𝙨 𝙑𝙞𝙚𝙬  
⚡ 𝙒𝙝𝙖𝙩𝙨𝘼𝙥𝙥 𝘼𝙪𝙩𝙤𝙢𝙖𝙩𝙞𝙤𝙣

---

## 📋 𝘾𝙤𝙢𝙢𝙖𝙣𝙙𝙨

```text
.ping       .alive       .setalive
.owner      .menu        .runtime
.tagall     .sticker     .s
.photo      .toimg      .vv
.whois      .repo       .autostatus
```

---

## 🛠️ 𝙎𝙚𝙩𝙪𝙥

```bash
git clone https://github.com/luttuxer/Luttuxer-MD.git
cd Luttuxer-MD
npm install
npm start
```

---

## ⚠️ 𝙄𝙢𝙥𝙤𝙧𝙩𝙖𝙣𝙩

Never upload WhatsApp authentication files, passwords, API keys, or other private credentials to GitHub.

---
## 👨🏻‍💻 Developer

<p align="center">
  <b>𝐋𝛖𝛕𝛕𝛂𝛒𝛊／🌷💭⭒𐂂</b>
</p>

## 🔗 Connect With Me

<p align="center">
  <a href="https://wa.me/917907914657">
    <img src="https://img.shields.io/badge/WhatsApp-Contact-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/>
  </a>
  <a href="https://t.me/luttappiser">
    <img src="https://img.shields.io/badge/Telegram-Connect-26A5E4?style=for-the-badge&logo=telegram&logoColor=white"/>
  </a>
  <a href="https://www.instagram.com/who.__iam_._/">
    <img src="https://img.shields.io/badge/Instagram-Follow-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/>
  </a>
</p>

---

<p align="center">
  Made with -` 𝐋𝛖𝛕𝛕𝛂𝛒𝛊／🌷💭⭒𐂂  
</p>
